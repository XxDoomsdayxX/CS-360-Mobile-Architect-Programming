package com.zybooks.stockvault;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameField, passwordField;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Initialize the database
        database = openOrCreateDatabase("StockVaultDB", MODE_PRIVATE, null);

        // Create the user table if it doesn't exist
        String createTableSQL = "CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY AUTOINCREMENT, firstName TEXT, lastName TEXT, dob TEXT, email TEXT, username TEXT, password TEXT, receiveNewsletter BOOLEAN);";
        database.execSQL(createTableSQL);

        // Set up the Login Button click listener
        loginButton.setOnClickListener(v -> login());

        // Set up the Create Account Button click listener to redirect to CreateAccountActivity
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
            startActivity(intent); // Launch CreateAccountActivity
        });
    }

    // Login method
    private void login() {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        // Validate the input fields
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the username and password match any records in the database
        Cursor cursor = database.rawQuery("SELECT * FROM Users WHERE username = ? AND password = ?", new String[]{username, password});

        if (cursor.moveToFirst()) {
            // Successful login
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();

            // Get the user data (username or first name) to pass to InventoryActivity
            @SuppressLint("Range") String firstName = cursor.getString(cursor.getColumnIndex("firstName"));

            // Start InventoryActivity and pass user data (including first name)
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            intent.putExtra("USER_NAME", firstName);  // Pass the user's first name to InventoryActivity
            startActivity(intent);

            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("USER_NAME", firstName);  // Save the user's first name
            editor.apply();

            // Optionally, you can finish the current activity to prevent returning to it
            finish();
        } else {
            // Invalid credentials
            Toast.makeText(this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }
}