package com.zybooks.stockvault;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventoryDB";
    private static final int DATABASE_VERSION = 3;

    // Table name and column names
    public static final String TABLE_NAME = "inventory";
    public static final String COL_ID = "id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_ITEM_QUANTITY = "item_quantity";
    public static final String COL_ITEM_PRICE = "item_price";
    public static final String COL_ITEM_DATE = "item_date";
    private Context context;
    private String userDbName;


    // Constructor
    public InventoryDatabase(Context context) {
        super(context, getUserDatabaseName(context), null, DATABASE_VERSION);  // Use the dynamic database name
        this.context = context;
    }

    // Method to get the user-specific database name using the username
    private static String getUserDatabaseName(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        String userName = sharedPreferences.getString("USER_NAME", "defaultUser");
        return DATABASE_NAME + userName;  // Use the username to generate the DB name
    }

    // This is called when the database is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createInventoryTableSQL = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_QUANTITY + " INTEGER, " +
                COL_ITEM_PRICE + " REAL, " +
                COL_ITEM_DATE + " TEXT);";
        db.execSQL(createInventoryTableSQL);

        // Creating the Users table
        String createUsersTableSQL = "CREATE TABLE IF NOT EXISTS Users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "firstName TEXT, " +
                "lastName TEXT, " +
                "dob TEXT, " +
                "email TEXT, " +
                "username TEXT, " +
                "password TEXT, " +
                "receiveNewsletter BOOLEAN);";
        db.execSQL(createUsersTableSQL);
    }

    // This is called when the database version is upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            String addColumn = "ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COL_ITEM_DATE + " TEXT";
            db.execSQL(addColumn);
        }

        // !!!!! Drop the Users table if you want to remove it (remove before updating version to prevent loss of data)
        db.execSQL("DROP TABLE IF EXISTS Users");

        // Recreate all tables (including the Users table)
        onCreate(db);

    }

    // Insert a new item into the database
    public void addItem(String itemName, int quantity, double price, String currentDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_ITEM_PRICE, price);
        values.put(COL_ITEM_DATE, currentDate);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Update an existing item
    public void updateItem(int id, String itemName, int quantity, double price, String currentDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_ITEM_PRICE, price);
        values.put(COL_ITEM_DATE, currentDate);
        db.update(TABLE_NAME, values, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Delete an item from the database
    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Get all items from the database
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, null, null, null, null, null, null);
    }
}