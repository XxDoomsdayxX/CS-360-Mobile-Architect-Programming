package com.zybooks.stockvault;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class InventoryActivity extends AppCompatActivity {

    private InventoryDatabase dbHelper;
    private EditText inputItemName, inputItemQty, inputItemPrice;
    private LinearLayout inventoryLayout;
    private boolean isPriceBeingSet = false;

    @SuppressLint({"WrongViewCast", "MissingInflatedId", "SetTextI18n", "ObsoleteSdkInt"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Ensure that dbHelper is initialized
        dbHelper = new InventoryDatabase(this);

        // Find the question mark button and set an OnClickListener
        ImageButton infoButton = findViewById(R.id.infoButton);
        infoButton.setOnClickListener(v -> showAppInfoDialog());

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String firstName = sharedPreferences.getString("USER_NAME", "User");  // Default to "User"

        // Set the welcome message with the user's first name
        TextView welcomeText = findViewById(R.id.welcomeText);
        welcomeText.setText("Greetings, " + firstName);

        // Create notification channel for notifications
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Inventory Notifications";
            String description = "Notifications for low stock and expiration alerts";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("inventory_channel", name, importance);
            channel.setDescription(description);

            // Register the channel with the system
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }

        // Find UI elements
        inputItemName = findViewById(R.id.inputItemName);
        inputItemQty = findViewById(R.id.inputItemQty);
        inputItemPrice = findViewById(R.id.inputItemPrice);
        ImageButton buttonAdd = findViewById(R.id.buttonAdd);
        inventoryLayout = findViewById(R.id.inventoryLayout); // LinearLayout to hold items dynamically

        // Add Item button click listener
        buttonAdd.setOnClickListener(v -> addItem());

        // Initially load the inventory items
        loadInventoryItems();
    }

    // Add item to the database
    private void addItem() {
        String itemName = inputItemName.getText().toString();
        String itemQty = inputItemQty.getText().toString();
        String itemPrice = inputItemPrice.getText().toString();

        // Get current date in MM/dd/yy format
        @SuppressLint("SimpleDateFormat") String currentDate = new SimpleDateFormat("MM/dd/yy").format(Calendar.getInstance().getTime());

        // Check for empty fields
        if (itemName.isEmpty() || itemQty.isEmpty() || itemPrice.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add item to the database
        dbHelper.addItem(itemName, Integer.parseInt(itemQty), Double.parseDouble(itemPrice), currentDate);

        // Clear the input fields
        inputItemName.setText("");
        inputItemQty.setText("");
        inputItemPrice.setText("");

        // Reload the inventory items to update the display
        loadInventoryItems();

        // Check for low stock and expiration after adding an item
        checkLowStockAndExpiration();

        Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
    }

    // Load the inventory items from the database and display them in the layout
    @SuppressLint("SetTextI18n")
    private void loadInventoryItems() {
        // Ensure databaseLayout is initialized
        inventoryLayout = findViewById(R.id.databaseLayout);

        // Check if inventoryLayout is available
        if (inventoryLayout == null) {
            // Handle error or return early if the database layout is not found
            Toast.makeText(this, "Error: Database layout not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Clear any existing views in the inventory layout
        inventoryLayout.removeAllViews();

        // Query the database for inventory items
        Cursor cursor = dbHelper.getAllItems();

        // Check if no items are found
        if (cursor == null || cursor.getCount() == 0) {
            // Create a TextView to show "No inventory items found."
            TextView noItemsMessage = new TextView(this);
            noItemsMessage.setText("No inventory items found.");
            noItemsMessage.setTextSize(18);  // Set text size
            noItemsMessage.setTextColor(getResources().getColor(android.R.color.black));  // Set text color
            inventoryLayout.addView(noItemsMessage);  // Add message to the layout
            assert cursor != null;
            cursor.close();  // Close cursor early
            return;  // Exit the method early if no items are found
        }

        // If items are found, proceed to display them in the layout
        if (cursor.moveToFirst()) {
            do {
                // Get data from the cursor for each item
                @SuppressLint("Range") String itemName = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_NAME));
                @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_QUANTITY));
                @SuppressLint("Range") String price = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_PRICE));
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_DATE)); // Date added
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(InventoryDatabase.COL_ID));

                // Create a new TableRow for each item
                TableRow row = new TableRow(this);
                row.setPadding(16, 8, 16, 8);

                // Create TextViews for item name, quantity, price, and date
                TextView nameView = new TextView(this);
                nameView.setText(itemName);
                nameView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
                inputItemName.setTextColor(Color.BLACK);
                inputItemName.setHintTextColor(Color.GRAY);
                row.addView(nameView);

                TextView qtyView = new TextView(this);
                qtyView.setText(String.valueOf(quantity));
                qtyView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
                inputItemQty.setTextColor(Color.BLACK);
                inputItemQty.setHintTextColor(Color.GRAY);
                row.addView(qtyView);

                TextView priceView = new TextView(this);
                priceView.setText(price);
                priceView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
                inputItemPrice.setTextColor(Color.BLACK);
                inputItemPrice.setHintTextColor(Color.GRAY);
                row.addView(priceView);

                TextView dateView = new TextView(this);
                dateView.setText(date);
                dateView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
                dateView.setEllipsize(android.text.TextUtils.TruncateAt.END);
                dateView.setMaxLines(1);
                row.addView(dateView);

                // Create delete button for each item
                ImageButton deleteButton = new ImageButton(this);
                deleteButton.setImageResource(R.drawable.ic_delete);
                deleteButton.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.5f));
                deleteButton.setOnClickListener(v -> deleteItem(id));
                row.addView(deleteButton);

                // Create notification button for each item
                ImageButton notifyButton = new ImageButton(this);
                notifyButton.setImageResource(R.drawable.ic_notifications);
                notifyButton.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.5f));
                notifyButton.setOnClickListener(v -> {
                    Intent intent = new Intent(InventoryActivity.this, NotificationSettingsActivity.class);
                    startActivity(intent);
                });
                row.addView(notifyButton);

                // Make Price and Quantity fields editable on long click
                priceView.setOnLongClickListener(v -> {
                    // Create EditText for price
                    EditText editPrice = new EditText(InventoryActivity.this);
                    editPrice.setText(price);
                    editPrice.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));

                    // Remove price TextView and add EditText in its place
                    row.removeView(priceView);
                    row.addView(editPrice, 2);

                    // Save updated price on "Enter"
                    editPrice.setOnEditorActionListener((v1, actionId, event) -> {
                        String newPrice = editPrice.getText().toString();
                        dbHelper.updateItem(id, itemName, quantity, Double.parseDouble(newPrice), date);
                        priceView.setText(newPrice); // Update the TextView with new price
                        row.removeView(editPrice); // Remove EditText
                        row.addView(priceView, 2); // Re-add the TextView back in the correct position
                        checkLowStockAndExpiration();
                        return true;
                    });

                    return true;
                });

                qtyView.setOnLongClickListener(v -> {
                    // Create EditText for quantity
                    EditText editQty = new EditText(InventoryActivity.this);
                    editQty.setText(String.valueOf(quantity));
                    editQty.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));

                    // Remove quantity TextView and add EditText in its place
                    row.removeView(qtyView);
                    row.addView(editQty, 1); // Add it at the same position as the original quantity

                    // Save updated quantity on "Enter"
                    editQty.setOnEditorActionListener((v1, actionId, event) -> {
                        String newQty = editQty.getText().toString();
                        dbHelper.updateItem(id, itemName, Integer.parseInt(newQty), Double.parseDouble(price), date);
                        qtyView.setText(newQty); // Update the TextView with new quantity
                        row.removeView(editQty); // Remove EditText
                        row.addView(qtyView, 1); // Re-add the TextView back in the correct position

                        // Check for low stock and expiration after updating the quantity
                        checkLowStockAndExpiration();

                        return true;
                    });

                    return true;
                });

                // Add the row to the database layout
                inventoryLayout.addView(row);
            } while (cursor.moveToNext());
        }
        cursor.close();  // Close the cursor after use
    }

    // Delete item by id
    private void deleteItem(int id) {
        dbHelper.deleteItem(id);
        loadInventoryItems(); // Reload the items after deletion
        Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
    }

    // Check if item expiration date is within the threshold
    private boolean isItemExpiringSoon(String dateAdded, int dateThresholdDays) {
        try {
            // Convert the dateAdded string into a Date object
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateAdded));

            // Calculate the difference between the current date and the date the item was added
            long timeDifference = System.currentTimeMillis() - calendar.getTimeInMillis();
            long daysDifference = timeDifference / (1000 * 60 * 60 * 24);  // Convert time difference to days

            // Return true if the item is expiring soon (within the threshold days)
            return daysDifference >= dateThresholdDays;
        } catch (Exception e) {
            Log.e("InventoryActivity", "Error parsing date: " + e.getMessage());
            return false;  // Return false if there's an error in parsing the date
        }
    }

    private void checkLowStockAndExpiration() {
        SharedPreferences sharedPreferences = getSharedPreferences("NotificationPreferences", MODE_PRIVATE);
        boolean enableSms = sharedPreferences.getBoolean("enableSms", false);
        String threshold = sharedPreferences.getString("threshold", "5");  // Default threshold value is 5
        boolean enableDateNotification = sharedPreferences.getBoolean("enableDateNotification", false);
        String dateThreshold = sharedPreferences.getString("dateThreshold", "30");  // Default value is 30 days

        // Ensure the threshold is a valid integer
        int lowStockThreshold = 5; // Default to 5 if invalid value is provided
        try {
            if (!threshold.isEmpty()) {
                lowStockThreshold = Integer.parseInt(threshold);
            }
        } catch (NumberFormatException e) {
            Log.e("InventoryActivity", "Invalid threshold value: " + threshold + ", defaulting to 5");
        }

        int dateThresholdDays = 30;  // Default value is 30 days
        try {
            if (!dateThreshold.isEmpty()) {
                dateThresholdDays = Integer.parseInt(dateThreshold);
            }
        } catch (NumberFormatException e) {
            Log.e("InventoryActivity", "Invalid date threshold value: " + dateThreshold + ", defaulting to 30");
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryDatabase.TABLE_NAME, null);

        while (cursor.moveToNext()) {
            @SuppressLint("Range") String itemName = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_NAME));
            @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_QUANTITY));
            @SuppressLint("Range") String price = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_PRICE));
            @SuppressLint("Range") String dateAdded = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COL_ITEM_DATE));

            Log.d("InventoryActivity", "Checking item: " + itemName + " with quantity: " + quantity);

            // Check for low stock notification
            if (quantity <= lowStockThreshold && enableSms) {
                Log.d("InventoryActivity", "Low stock alert triggered for " + itemName);
                sendLowStockNotification(itemName, quantity);
            }

            // Check for expiration notification
            if (enableDateNotification && isItemExpiringSoon(dateAdded, dateThresholdDays)) {
                sendExpirationNotification(itemName, dateAdded);
            }
        }
        cursor.close();
    }

    private void sendLowStockNotification(String itemName, int quantity) {
        // Create the notification content
        String message = "Low stock alert: " + itemName + " has only " + quantity + " units left in stock.";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "inventory_channel")
                .setSmallIcon(R.drawable.ic_notifications)  // Set a small icon for the notification
                .setContentTitle("Low Stock Alert")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);  // Automatically dismiss the notification when clicked

        // Get the NotificationManager system service to show the notification
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(1, builder.build());  // Unique ID for the notification
        }
    }

    private void sendExpirationNotification(String itemName, String dateAdded) {
        // Create the notification content
        String message = "Expiration alert: " + itemName + " was added on " + dateAdded + " and is approaching expiration.";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "inventory_channel")
                .setSmallIcon(R.drawable.ic_notifications)  // Set a small icon for the notification
                .setContentTitle("Expiration Alert")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);  // Automatically dismiss the notification when clicked

        // Get the NotificationManager system service to show the notification
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(2, builder.build());  // Unique ID for the notification
        }
    }

    private void showAppInfoDialog() {
        // Create an AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("How to Use the App");
        builder.setMessage("This app helps you manage your inventory. " +
                "\n\n- Add items with their name, quantity, and price." +
                "\n- Hold down on the option you would like to edit (qty, date)" +
                "\n- Set low stock threshold for notifications." +
                "\n- Receive notifications when stock is low or items are nearing expiration." +
                "\n\nEnjoy using the app!");
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        builder.setCancelable(true);

        // Show the dialog
        builder.show();
    }
}