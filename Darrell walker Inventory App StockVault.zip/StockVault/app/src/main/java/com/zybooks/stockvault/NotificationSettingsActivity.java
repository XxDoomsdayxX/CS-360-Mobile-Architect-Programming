package com.zybooks.stockvault;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class NotificationSettingsActivity extends AppCompatActivity {

    // We don't need the SMS_PERMISSION_CODE anymore as we're dealing with notifications
    private static final int NOTIFICATION_PERMISSION_CODE = 101;  // You can use this for notification permission request

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);  // Ensure you have the correct layout here

        SharedPreferences sharedPreferences = getSharedPreferences("NotificationPreferences", MODE_PRIVATE);

        // Initialize UI components
        CheckBox enableSmsCheckBox = findViewById(R.id.enableSms);
        EditText thresholdField = findViewById(R.id.thresholdField);
        CheckBox enableDateNotification = findViewById(R.id.enableDateNotification);
        EditText dateThresholdField = findViewById(R.id.dateThresholdField);

        // Load saved preferences
        boolean enableSms = sharedPreferences.getBoolean("enableSms", false);
        String threshold = sharedPreferences.getString("threshold", "5");  // Default value is 5
        enableDateNotification.setChecked(sharedPreferences.getBoolean("enableDateNotification", false));
        String dateThreshold = sharedPreferences.getString("dateThreshold", "30");  // Default value is 30

        // Set values in the UI
        enableSmsCheckBox.setChecked(enableSms);
        thresholdField.setText(threshold);
        dateThresholdField.setText(dateThreshold);

        // Handle the save button click to save preferences
        Button saveButton = findViewById(R.id.saveSettingsBtn);
        saveButton.setOnClickListener(v -> {
            saveNotificationPreferences();
            // Close the activity and return to InventoryActivity
            Intent intent = new Intent(NotificationSettingsActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        });

        // Check if the app has permission to show notifications (only for Android 13 and above)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Request notification permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_CODE);
        }
    }

    private void saveNotificationPreferences() {
        // Get SharedPreferences and editor
        SharedPreferences sharedPreferences = getSharedPreferences("NotificationPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Retrieve values from UI components
        boolean enableSms = ((CheckBox) findViewById(R.id.enableSms)).isChecked();
        String threshold = ((EditText) findViewById(R.id.thresholdField)).getText().toString();
        boolean enableDateNotification = ((CheckBox) findViewById(R.id.enableDateNotification)).isChecked();
        String dateThreshold = ((EditText) findViewById(R.id.dateThresholdField)).getText().toString();

        // Save preferences
        editor.putBoolean("enableSms", enableSms);
        editor.putString("threshold", threshold);
        editor.putBoolean("enableDateNotification", enableDateNotification);
        editor.putString("dateThreshold", dateThreshold);
        editor.apply();  // Apply the changes

        // Show confirmation message
        Toast.makeText(this, "Preferences saved!", Toast.LENGTH_SHORT).show();
    }

    // Callback for the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification Permission Granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Notification Permission Denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}