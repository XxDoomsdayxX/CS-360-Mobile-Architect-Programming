package com.zybooks.stockvault;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText firstNameField, lastNameField, dobField, emailField, createUsernameField, createPasswordField;
    private CheckBox newsletterCheckbox;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Initialize UI components
        firstNameField = findViewById(R.id.firstNameField);
        lastNameField = findViewById(R.id.lastNameField);
        dobField = findViewById(R.id.dobField);
        emailField = findViewById(R.id.emailField);
        createUsernameField = findViewById(R.id.createUsernameField);
        createPasswordField = findViewById(R.id.createPasswordField);
        newsletterCheckbox = findViewById(R.id.newsletterCheckbox);
        Button createAccountSubmitButton = findViewById(R.id.createAccountSubmitButton);

        // Initialize the database
        database = openOrCreateDatabase("StockVaultDB", MODE_PRIVATE, null);

        // Create the user table if it doesn't exist
        String createTableSQL = "CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY AUTOINCREMENT, firstName TEXT, lastName TEXT, dob TEXT, email TEXT, username TEXT, password TEXT, receiveNewsletter BOOLEAN);";
        database.execSQL(createTableSQL);

        // Add the TextWatcher for the DOB field
        dobField.addTextChangedListener(new TextWatcher() {
            private boolean isFormatting = false; // Flag to prevent recursion

            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable editable) {
                if (isFormatting) return;  // Prevent recursive updates

                String input = editable.toString();

                // Remove all non-numeric characters
                String cleanInput = input.replaceAll("[^\\d]", "");

                // Apply the format MM/DD/YYYY
                String formattedInput = cleanInput;
                if (formattedInput.length() >= 3) {
                    formattedInput = formattedInput.substring(0, 2) + "/" + formattedInput.substring(2);
                }
                if (formattedInput.length() >= 6) {
                    formattedInput = formattedInput.substring(0, 5) + "/" + formattedInput.substring(5, 10);
                }

                // Set the flag to prevent recursive updates
                isFormatting = true;

                // Temporarily remove the TextWatcher to prevent recursion
                dobField.removeTextChangedListener(this);

                // Set the formatted text
                dobField.setText(formattedInput);

                // Move the cursor to the end of the text
                dobField.setSelection(formattedInput.length());

                // Add the TextWatcher back after the update
                dobField.addTextChangedListener(this);

                // Reset the flag
                isFormatting = false;
            }
        });

        // Create Account Button Click Listener
        createAccountSubmitButton.setOnClickListener(v -> signUp());
    }

    // Method for signing up a user
    private void signUp() {
        String firstName = firstNameField.getText().toString();
        String lastName = lastNameField.getText().toString();
        String dob = dobField.getText().toString();
        String email = emailField.getText().toString();
        String username = createUsernameField.getText().toString();
        String password = createPasswordField.getText().toString();
        boolean receiveNewsletter = newsletterCheckbox.isChecked();

        // Basic validation
        if (TextUtils.isEmpty(firstName) || TextUtils.isEmpty(lastName) || TextUtils.isEmpty(dob) || TextUtils.isEmpty(email) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate username
        if (!validateUsername(username)) {
            Toast.makeText(this, "Username must be alphanumeric and at least 5 characters.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate password
        if (!validatePassword(password)) {
            Toast.makeText(this, "Password must be at least 8 characters and contain upper, lower, number, and special characters.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate email format
        if (!validateEmail(email)) {
            Toast.makeText(this, "Invalid email format.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate birthday
        if (!validateBirthday(dob)) {
            Toast.makeText(this, "Invalid birthday or age under 18.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the email already exists
        if (checkIfEmailExists(email)) {
            Toast.makeText(this, "Email is already in use. Please use a different email address.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the username already exists
        if (checkIfUsernameExists(username)) {
            Toast.makeText(this, "Username already exists. Please use a different username.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Insert the new user into the database
            database.execSQL("INSERT INTO Users (firstName, lastName, dob, email, username, password, receiveNewsletter) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    new Object[]{firstName, lastName, dob, email, username, password, receiveNewsletter});
            Toast.makeText(this, "Sign Up Successful! You can now log in.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("DatabaseError", "Error inserting user into database: " + e.getMessage());
            Toast.makeText(this, "An error occurred while signing up. Please try again.", Toast.LENGTH_SHORT).show();
        }

        finish(); // Close the Create Account Activity and go back to Login Screen
    }

    // Validate the username (must be alphanumeric and at least 5 characters long)
    private boolean validateUsername(String username) {
        return username.length() >= 5 && username.matches("[a-zA-Z0-9]+");
    }

    // Validate the password (must be at least 8 characters long, include upper, lower, number, and special characters)
    private boolean validatePassword(String password) {
        String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        Pattern pattern = Pattern.compile(passwordPattern);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    // Validate the email format using the built-in Android Patterns class
    private boolean validateEmail(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    // Validate if the birthday is valid and if the user is at least 18 years old
    private boolean validateBirthday(String birthday) {
        try {
            @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            Date date = dateFormat.parse(birthday);
            if (date == null) {
                return false; // Invalid date
            }
            Calendar calendar = Calendar.getInstance();
            int age = calendar.get(Calendar.YEAR) - (date.getYear() + 1900);  // Date.getYear() returns years since 1900
            return age >= 16;  // Check if the user is at least 16 years old
        } catch (Exception e) {
            return false;
        }
    }

    // Check if the email already exists in the database
    // Check if the email already exists in the database
    private boolean checkIfEmailExists(String email) {
        boolean exists = false;
        Cursor cursor = null;
        try {
            cursor = database.rawQuery("SELECT * FROM Users WHERE email = ?", new String[]{email});
            exists = cursor.moveToFirst();  // If cursor is not empty, email exists
        } catch (Exception e) {
            Log.e("DatabaseError", "Error checking email: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return exists;
    }

    // Check if the username already exists in the database
    // Check if the username already exists in the database
    private boolean checkIfUsernameExists(String username) {
        boolean exists = false;
        Cursor cursor = null;
        try {
            cursor = database.rawQuery("SELECT * FROM Users WHERE username = ?", new String[]{username});
            exists = cursor.moveToFirst();  // If cursor is not empty, username exists
        } catch (Exception e) {
            Log.e("DatabaseError", "Error checking username: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return exists;
    }
}